/*
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.php.net/license/3_01.txt                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " './configure'  '--prefix=@@HOMEBREW_CELLAR@@/php/8.0.0_1' '--localstatedir=@@HOMEBREW_PREFIX@@/var' '--sysconfdir=@@HOMEBREW_PREFIX@@/etc/php/8.0' '--with-config-file-path=@@HOMEBREW_PREFIX@@/etc/php/8.0' '--with-config-file-scan-dir=@@HOMEBREW_PREFIX@@/etc/php/8.0/conf.d' '--with-pear=@@HOMEBREW_CELLAR@@/php/8.0.0_1/share/php/pear' '--with-os-sdkpath=/Library/Developer/CommandLineTools/SDKs/MacOSX11.1.sdk' '--enable-bcmath' '--enable-calendar' '--enable-dba' '--enable-dtrace' '--enable-exif' '--enable-ftp' '--enable-fpm' '--enable-gd' '--enable-intl' '--enable-mbregex' '--enable-mbstring' '--enable-mysqlnd' '--enable-pcntl' '--enable-phpdbg' '--enable-phpdbg-readline' '--enable-phpdbg-webhelper' '--enable-shmop' '--enable-soap' '--enable-sockets' '--enable-sysvmsg' '--enable-sysvsem' '--enable-sysvshm' '--with-apxs2=@@HOMEBREW_PREFIX@@/opt/httpd/bin/apxs' '--with-bz2=/Library/Developer/CommandLineTools/SDKs/MacOSX11.1.sdk/usr' '--with-curl' '--with-external-gd' '--with-external-pcre' '--with-ffi' '--with-fpm-user=_www' '--with-fpm-group=_www' '--with-gettext=@@HOMEBREW_PREFIX@@/opt/gettext' '--with-gmp=@@HOMEBREW_PREFIX@@/opt/gmp' '--with-iconv=/Library/Developer/CommandLineTools/SDKs/MacOSX11.1.sdk/usr' '--with-kerberos' '--with-layout=GNU' '--with-ldap=@@HOMEBREW_PREFIX@@/opt/openldap' '--with-ldap-sasl' '--with-libxml' '--with-libedit' '--with-mhash=/Library/Developer/CommandLineTools/SDKs/MacOSX11.1.sdk/usr' '--with-mysql-sock=/tmp/mysql.sock' '--with-mysqli=mysqlnd' '--with-ndbm=/Library/Developer/CommandLineTools/SDKs/MacOSX11.1.sdk/usr' '--with-openssl' '--with-password-argon2=@@HOMEBREW_PREFIX@@/opt/argon2' '--with-pdo-dblib=@@HOMEBREW_PREFIX@@/opt/freetds' '--with-pdo-mysql=mysqlnd' '--with-pdo-odbc=unixODBC,@@HOMEBREW_PREFIX@@/opt/unixodbc' '--with-pdo-pgsql=@@HOMEBREW_PREFIX@@/opt/libpq' '--with-pdo-sqlite' '--with-pgsql=@@HOMEBREW_PREFIX@@/opt/libpq' '--with-pic' '--with-pspell=@@HOMEBREW_PREFIX@@/opt/aspell' '--with-sodium' '--with-sqlite3' '--with-tidy=@@HOMEBREW_PREFIX@@/opt/tidy-html5' '--with-unixODBC' '--with-xmlrpc' '--with-xsl' '--with-zip' '--with-zlib' 'PKG_CONFIG_PATH=@@HOMEBREW_PREFIX@@/opt/openssl@1.1/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/argon2/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/brotli/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/libidn2/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/libmetalink/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/libssh2/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/c-ares/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/jemalloc/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/nghttp2/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/rtmpdump/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/zstd/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/curl/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/unixodbc/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/libpng/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/freetype/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/fontconfig/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/jpeg/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/libtiff/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/webp/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/gd/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/libffi/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/pcre/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/readline/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/sqlite/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/xz/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/python@3.9/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/glib/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/gmp/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/icu4c/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/krb5/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/libpq/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/libsodium/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/libzip/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/oniguruma/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/pcre2/lib/pkgconfig:@@HOMEBREW_PREFIX@@/opt/tidy-html5/lib/pkgconfig' 'PKG_CONFIG_LIBDIR=/usr/lib/pkgconfig:@@HOMEBREW_PREFIX@@/Library/Homebrew/os/mac/pkgconfig/11.1' 'SASL_CFLAGS=-I/Library/Developer/CommandLineTools/SDKs/MacOSX11.1.sdk/usr/include/sasl' 'SASL_LIBS=-lsasl2'"
#define PHP_ODBC_CFLAGS	"-I@@HOMEBREW_CELLAR@@/unixodbc/2.3.9/include"
#define PHP_ODBC_LFLAGS		""
#define PHP_ODBC_LIBS		"-L@@HOMEBREW_CELLAR@@/unixodbc/2.3.9/lib -lodbc"
#define PHP_ODBC_TYPE		"unixODBC"
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         "@@HOMEBREW_CELLAR@@/php/8.0.0_1/share/php/pear"
#define PHP_INCLUDE_PATH	".:@@HOMEBREW_CELLAR@@/php/8.0.0_1/share/php/pear"
#define PHP_EXTENSION_DIR       "@@HOMEBREW_CELLAR@@/php/8.0.0_1/lib/php/20200930"
#define PHP_PREFIX              "@@HOMEBREW_CELLAR@@/php/8.0.0_1"
#define PHP_BINDIR              "@@HOMEBREW_CELLAR@@/php/8.0.0_1/bin"
#define PHP_SBINDIR             "@@HOMEBREW_CELLAR@@/php/8.0.0_1/sbin"
#define PHP_MANDIR              "@@HOMEBREW_CELLAR@@/php/8.0.0_1/share/man"
#define PHP_LIBDIR              "@@HOMEBREW_CELLAR@@/php/8.0.0_1/lib/php"
#define PHP_DATADIR             "@@HOMEBREW_CELLAR@@/php/8.0.0_1/share/php"
#define PHP_SYSCONFDIR          "@@HOMEBREW_PREFIX@@/etc/php/8.0"
#define PHP_LOCALSTATEDIR       "@@HOMEBREW_PREFIX@@/var"
#define PHP_CONFIG_FILE_PATH    "@@HOMEBREW_PREFIX@@/etc/php/8.0"
#define PHP_CONFIG_FILE_SCAN_DIR    "@@HOMEBREW_PREFIX@@/etc/php/8.0/conf.d"
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
