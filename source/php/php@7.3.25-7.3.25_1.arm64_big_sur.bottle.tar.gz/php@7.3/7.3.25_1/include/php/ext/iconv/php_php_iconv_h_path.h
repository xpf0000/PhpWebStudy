#define PHP_ICONV_H_PATH </Library/Developer/CommandLineTools/SDKs/MacOSX11.1.sdk/usr/include/iconv.h>
