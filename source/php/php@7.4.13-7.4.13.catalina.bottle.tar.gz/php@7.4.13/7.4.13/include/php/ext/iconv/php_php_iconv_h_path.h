#define PHP_ICONV_H_PATH </Library/Developer/CommandLineTools/SDKs/MacOSX10.15.sdk/usr/include/iconv.h>
