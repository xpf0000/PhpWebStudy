#define PHP_ICONV_H_PATH </Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include/iconv.h>
