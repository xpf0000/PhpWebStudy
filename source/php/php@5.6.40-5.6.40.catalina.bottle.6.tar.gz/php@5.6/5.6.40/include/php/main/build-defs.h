/*                                                                -*- C -*-
   +----------------------------------------------------------------------+
   | PHP Version 5                                                        |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997-2016 The PHP Group                                |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.php.net/license/3_01.txt                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig S�ther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

/* $Id$ */

#define CONFIGURE_COMMAND " './configure'  '--prefix=@@HOMEBREW_CELLAR@@/php@5.6/5.6.40' '--localstatedir=@@HOMEBREW_PREFIX@@/var' '--sysconfdir=@@HOMEBREW_PREFIX@@/etc/php/5.6' '--with-config-file-path=@@HOMEBREW_PREFIX@@/etc/php/5.6' '--with-config-file-scan-dir=@@HOMEBREW_PREFIX@@/etc/php/5.6/conf.d' '--with-pear=@@HOMEBREW_CELLAR@@/php@5.6/5.6.40/share/php@5.6/pear' '--enable-bcmath' '--enable-calendar' '--enable-dba' '--enable-exif' '--enable-ftp' '--enable-fpm' '--enable-intl' '--enable-mbregex' '--enable-mbstring' '--enable-mysqlnd' '--enable-pcntl' '--enable-phpdbg' '--enable-shmop' '--enable-soap' '--enable-sockets' '--enable-sysvmsg' '--enable-sysvsem' '--enable-sysvshm' '--enable-wddx' '--enable-zip' '--with-apxs2=@@HOMEBREW_PREFIX@@/opt/httpd/bin/apxs' '--with-bz2=/Library/Developer/CommandLineTools/SDKs/MacOSX10.15.sdk/usr' '--with-curl=@@HOMEBREW_PREFIX@@/opt/curl' '--with-fpm-user=_www' '--with-fpm-group=_www' '--with-freetype-dir=@@HOMEBREW_PREFIX@@/opt/freetype' '--with-gd' '--with-gettext=@@HOMEBREW_PREFIX@@/opt/gettext' '--with-gmp=@@HOMEBREW_PREFIX@@/opt/gmp' '--with-iconv=/Library/Developer/CommandLineTools/SDKs/MacOSX10.15.sdk/usr' '--with-icu-dir=@@HOMEBREW_PREFIX@@/opt/icu4c' '--with-jpeg-dir=@@HOMEBREW_PREFIX@@/opt/jpeg' '--with-kerberos=/Library/Developer/CommandLineTools/SDKs/MacOSX10.15.sdk/usr' '--with-layout=GNU' '--with-ldap=@@HOMEBREW_PREFIX@@/opt/openldap' '--with-ldap-sasl=/Library/Developer/CommandLineTools/SDKs/MacOSX10.15.sdk/usr' '--with-libedit=/Library/Developer/CommandLineTools/SDKs/MacOSX10.15.sdk/usr' '--with-libxml-dir=/Library/Developer/CommandLineTools/SDKs/MacOSX10.15.sdk/usr' '--with-libzip' '--with-mcrypt=@@HOMEBREW_PREFIX@@/opt/mcrypt' '--with-mhash=/Library/Developer/CommandLineTools/SDKs/MacOSX10.15.sdk/usr' '--with-mysql-sock=/tmp/mysql.sock' '--with-mysqli=mysqlnd' '--with-mysql=mysqlnd' '--with-ndbm=/Library/Developer/CommandLineTools/SDKs/MacOSX10.15.sdk/usr' '--with-openssl=@@HOMEBREW_PREFIX@@/opt/openssl@1.1' '--with-pdo-dblib=@@HOMEBREW_PREFIX@@/opt/freetds' '--with-pdo-mysql=mysqlnd' '--with-pdo-odbc=unixODBC,@@HOMEBREW_PREFIX@@/opt/unixodbc' '--with-pdo-pgsql=@@HOMEBREW_PREFIX@@/opt/libpq' '--with-pdo-sqlite=@@HOMEBREW_PREFIX@@/opt/sqlite' '--with-pgsql=@@HOMEBREW_PREFIX@@/opt/libpq' '--with-pic' '--with-png-dir=@@HOMEBREW_PREFIX@@/opt/libpng' '--with-pspell=@@HOMEBREW_PREFIX@@/opt/aspell' '--with-sqlite3=@@HOMEBREW_PREFIX@@/opt/sqlite' '--with-tidy=@@HOMEBREW_PREFIX@@/opt/tidy-html5' '--with-unixODBC=@@HOMEBREW_PREFIX@@/opt/unixodbc' '--with-xmlrpc' '--with-xsl=/Library/Developer/CommandLineTools/SDKs/MacOSX10.15.sdk/usr' '--with-zlib=/Library/Developer/CommandLineTools/SDKs/MacOSX10.15.sdk/usr' 'CC=clang' 'CFLAGS=-Wno-implicit-function-declaration' 'CPPFLAGS=-DU_USING_ICU_NAMESPACE=1' 'CXX=clang++'"
#define PHP_ADA_INCLUDE		""
#define PHP_ADA_LFLAGS		""
#define PHP_ADA_LIBS		""
#define PHP_APACHE_INCLUDE	""
#define PHP_APACHE_TARGET	""
#define PHP_FHTTPD_INCLUDE      ""
#define PHP_FHTTPD_LIB          ""
#define PHP_FHTTPD_TARGET       ""
#define PHP_CFLAGS		"$(CFLAGS_CLEAN) -prefer-non-pic -static"
#define PHP_DBASE_LIB		""
#define PHP_BUILD_DEBUG		""
#define PHP_GDBM_INCLUDE	""
#define PHP_IBASE_INCLUDE	""
#define PHP_IBASE_LFLAGS	""
#define PHP_IBASE_LIBS		""
#define PHP_IFX_INCLUDE		""
#define PHP_IFX_LFLAGS		""
#define PHP_IFX_LIBS		""
#define PHP_INSTALL_IT		"$(mkinstalldirs) '$(INSTALL_ROOT)@@HOMEBREW_CELLAR@@/php@5.6/5.6.40/lib/httpd/modules' &&                  @@HOMEBREW_PREFIX@@/opt/httpd/bin/apxs -S LIBEXECDIR='@@HOMEBREW_CELLAR@@/php\@5.6/5.6.40/lib/httpd/modules'                        -i -n php5 libs/libphp5.so"
#define PHP_IODBC_INCLUDE	""
#define PHP_IODBC_LFLAGS	""
#define PHP_IODBC_LIBS		""
#define PHP_MSQL_INCLUDE	""
#define PHP_MSQL_LFLAGS		""
#define PHP_MSQL_LIBS		""
#define PHP_MYSQL_INCLUDE	""
#define PHP_MYSQL_LIBS		""
#define PHP_MYSQL_TYPE		""
#define PHP_ODBC_INCLUDE	"-I@@HOMEBREW_PREFIX@@/opt/unixodbc/include"
#define PHP_ODBC_LFLAGS		"-L@@HOMEBREW_PREFIX@@/opt/unixodbc/lib"
#define PHP_ODBC_LIBS		"-lodbc"
#define PHP_ODBC_TYPE		"unixODBC"
#define PHP_OCI8_SHARED_LIBADD 	""
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_ORACLE_SHARED_LIBADD 	"@ORACLE_SHARED_LIBADD@"
#define PHP_ORACLE_DIR				"@ORACLE_DIR@"
#define PHP_ORACLE_VERSION			"@ORACLE_VERSION@"
#define PHP_PGSQL_INCLUDE	""
#define PHP_PGSQL_LFLAGS	""
#define PHP_PGSQL_LIBS		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PHP_SOLID_INCLUDE	""
#define PHP_SOLID_LIBS		""
#define PHP_EMPRESS_INCLUDE	""
#define PHP_EMPRESS_LIBS	""
#define PHP_SYBASE_INCLUDE	""
#define PHP_SYBASE_LFLAGS	""
#define PHP_SYBASE_LIBS		""
#define PHP_DBM_TYPE		""
#define PHP_DBM_LIB		""
#define PHP_LDAP_LFLAGS		""
#define PHP_LDAP_INCLUDE	""
#define PHP_LDAP_LIBS		""
#define PHP_BIRDSTEP_INCLUDE     ""
#define PHP_BIRDSTEP_LIBS        ""
#define PEAR_INSTALLDIR         "@@HOMEBREW_CELLAR@@/php@5.6/5.6.40/share/php@5.6/pear"
#define PHP_INCLUDE_PATH	".:@@HOMEBREW_CELLAR@@/php@5.6/5.6.40/share/php@5.6/pear"
#define PHP_EXTENSION_DIR       "@@HOMEBREW_CELLAR@@/php@5.6/5.6.40/lib/php/20131226"
#define PHP_PREFIX              "@@HOMEBREW_CELLAR@@/php@5.6/5.6.40"
#define PHP_BINDIR              "@@HOMEBREW_CELLAR@@/php@5.6/5.6.40/bin"
#define PHP_SBINDIR             "@@HOMEBREW_CELLAR@@/php@5.6/5.6.40/sbin"
#define PHP_MANDIR              "@@HOMEBREW_CELLAR@@/php@5.6/5.6.40/share/man"
#define PHP_LIBDIR              "@@HOMEBREW_CELLAR@@/php@5.6/5.6.40/lib/php"
#define PHP_DATADIR             "@@HOMEBREW_CELLAR@@/php@5.6/5.6.40/share/php"
#define PHP_SYSCONFDIR          "@@HOMEBREW_PREFIX@@/etc/php/5.6"
#define PHP_LOCALSTATEDIR       "@@HOMEBREW_PREFIX@@/var"
#define PHP_CONFIG_FILE_PATH    "@@HOMEBREW_PREFIX@@/etc/php/5.6"
#define PHP_CONFIG_FILE_SCAN_DIR    "@@HOMEBREW_PREFIX@@/etc/php/5.6/conf.d"
#define PHP_SHLIB_SUFFIX        "so"
