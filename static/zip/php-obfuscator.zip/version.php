<?php
//========================================================================
// Author:  Pascal KISSIAN
// Resume:  https://pascal.kissian.net
//
// Copyright (c) 2015-2021 Pascal KISSIAN
//
// Published under the MIT License
//          Consider it as a proof of concept!
//          No warranty of any kind.
//          Use and abuse at your own risks.
//========================================================================

$yakpro_po_version = "2.0.14";

?>